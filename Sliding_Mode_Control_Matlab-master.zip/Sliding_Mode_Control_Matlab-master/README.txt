Hi, I'm learnning SMC, and using Matlab to do the 
simulation in the Windows.
So, I make a repo for my Windows OS, and it seems cool as Linux
