本程序为简单的自适应控制器设计
来自刘金琨----《滑膜变结构控制MATLAB仿真-基本理论和设计方法》
Simulink uses Fixed-step---ode4
